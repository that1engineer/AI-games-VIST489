# Moonwake Swarm

A tiny vanilla HTML/CSS/JavaScript survival shooter prototype inspired by the roguelite auto-attacker format.

## Run

Open `index.html` in a browser.

No install step, no server, no build tools.

## Controls

- Move: `WASD` or arrow keys
- Pick level-up upgrade: click a card or press `1`, `2`, `3`
- Pause: `P`

## Prototype Notes

- The game is deterministic with a fixed RNG seed in `game.js`.
- Survive to `5:00` to spawn the Bell Ghast miniboss.
- The prototype uses canvas shapes instead of external sprite files so it is immediately runnable.
- Replace the shape drawing in `draw()` with sprite rendering when assets are ready.

## Files

- `index.html`: canvas, HUD, upgrade modal, restart modal
- `styles.css`: layout, HUD, modal, responsive behavior
- `game.js`: main loop, movement, spawning, scaling, weapons, XP, upgrades
- `data/*.json`: sample design data to migrate toward a data-driven version
