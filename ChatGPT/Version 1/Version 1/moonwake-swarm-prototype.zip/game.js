"use strict";

const canvas = document.querySelector("#game");
const ctx = canvas.getContext("2d");

const ui = {
  hpBar: document.querySelector("#hpBar"),
  hpText: document.querySelector("#hpText"),
  xpBar: document.querySelector("#xpBar"),
  levelText: document.querySelector("#levelText"),
  killText: document.querySelector("#killText"),
  timer: document.querySelector("#timer"),
  waveText: document.querySelector("#waveText"),
  upgradeModal: document.querySelector("#upgradeModal"),
  upgradeCards: document.querySelector("#upgradeCards"),
  gameOver: document.querySelector("#gameOver"),
  gameOverTitle: document.querySelector("#gameOverTitle"),
  gameOverStats: document.querySelector("#gameOverStats"),
  restartButton: document.querySelector("#restartButton")
};

const keys = {};
let seed = 20260426;
const rand = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296);
const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
const pick = (arr) => arr[Math.floor(rand() * arr.length)];

const enemyDefs = {
  murkling: { name: "Murkling", hp: 10, dmg: 6, speed: 45, xp: 2, r: 13, color: "#604b7a" },
  bat: { name: "Needle Bat", hp: 7, dmg: 5, speed: 85, xp: 2, r: 10, color: "#8a5c72" },
  slug: { name: "Grave Slug", hp: 28, dmg: 9, speed: 25, xp: 5, r: 17, color: "#3c2f4f" },
  imp: { name: "Ash Imp", hp: 14, dmg: 7, speed: 58, xp: 3, r: 12, color: "#ba6d5a" },
  wisp: { name: "Lantern Wisp", hp: 18, dmg: 6, speed: 38, xp: 4, r: 14, color: "#7ed7c1" },
  husk: { name: "Crowd Husk", hp: 24, dmg: 8, speed: 32, xp: 5, r: 16, color: "#6f667d" },
  boss: { name: "Bell Ghast", hp: 1500, dmg: 18, speed: 28, xp: 50, r: 34, color: "#f5d67b" }
};

const weaponDefs = {
  ember: {
    name: "Ember Needle",
    desc: "Fires at the nearest enemy and applies burn.",
    damage: 8,
    rate: 0.45,
    range: 270,
    speed: 430,
    color: "#ff9f43"
  },
  bell: {
    name: "Grave Bell",
    desc: "Pulses around you, damaging nearby enemies.",
    damage: 18,
    rate: 2.2,
    range: 82,
    color: "#f5d67b"
  },
  spark: {
    name: "Widow Spark",
    desc: "Zaps several enemies in range.",
    damage: 11,
    rate: 1.6,
    range: 210,
    color: "#6ee7ff"
  }
};

const upgrades = [
  { type: "weapon", id: "ember", name: "Ember Needle +", desc: "+3 damage and longer burn.", apply: s => { s.weapons.ember.damage += 3; s.burnTime += 0.25; } },
  { type: "weapon", id: "bell", name: "Grave Bell", desc: "Add or improve your close-range pulse.", apply: s => addOrUpgradeWeapon(s, "bell") },
  { type: "weapon", id: "spark", name: "Widow Spark", desc: "Add or improve chain lightning.", apply: s => addOrUpgradeWeapon(s, "spark") },
  { type: "artifact", name: "Magnet Brooch", desc: "+55% pickup radius.", apply: s => { s.pickupRadius *= 1.55; } },
  { type: "artifact", name: "Oil Wick", desc: "Burn lasts +1.5 seconds.", apply: s => { s.burnTime += 1.5; } },
  { type: "artifact", name: "Split Flint", desc: "Burned enemies explode on death.", apply: s => { s.splitFlint = true; } },
  { type: "artifact", name: "Pocket Sundial", desc: "All weapon cooldowns -10%.", apply: s => { s.cooldownMult *= 0.9; } },
  { type: "artifact", name: "Running Shoes", desc: "+12% move speed.", apply: s => { s.player.speed *= 1.12; } },
  { type: "artifact", name: "Cracked Lens", desc: "+8% crit chance.", apply: s => { s.crit += 0.08; } }
];

let state;

function makeState() {
  return {
    time: 0,
    last: 0,
    paused: false,
    choosing: false,
    over: false,
    kills: 0,
    spawnCarry: 0,
    pulse: 0,
    burnTime: 2,
    pickupRadius: 30,
    cooldownMult: 1,
    crit: 0.05,
    splitFlint: false,
    enemies: [],
    bullets: [],
    pickups: [],
    floaters: [],
    weapons: {
      ember: { id: "ember", level: 1, cd: 0, damage: 8 }
    },
    player: { x: 480, y: 270, r: 14, hp: 100, maxHp: 100, speed: 165, xp: 0, level: 1 }
  };
}

function addOrUpgradeWeapon(s, id) {
  if (!s.weapons[id]) {
    s.weapons[id] = { id, level: 1, cd: 0, damage: weaponDefs[id].damage };
    return;
  }
  s.weapons[id].level += 1;
  s.weapons[id].damage += id === "bell" ? 8 : 5;
}

function resize() {
  const rect = canvas.getBoundingClientRect();
  canvas.width = Math.floor(rect.width * devicePixelRatio);
  canvas.height = Math.floor(rect.height * devicePixelRatio);
  ctx.setTransform(devicePixelRatio, 0, 0, devicePixelRatio, 0, 0);
}

function minute() {
  return state.time / 60;
}

function scaledEnemy(id, elite = false) {
  const def = enemyDefs[id];
  const m = minute();
  const mult = elite ? 4 : 1;
  return {
    id,
    name: def.name,
    x: 0,
    y: 0,
    r: elite ? def.r * 1.35 : def.r,
    hp: Math.round(def.hp * (1 + 0.22 * m) * mult),
    maxHp: Math.round(def.hp * (1 + 0.22 * m) * mult),
    dmg: Math.round(def.dmg * (1 + 0.10 * m) * (elite ? 1.5 : 1)),
    speed: def.speed + Math.min(30, 2.5 * m) + (elite ? 8 : 0),
    xp: elite ? def.xp * 5 : def.xp,
    color: def.color,
    elite,
    burn: 0
  };
}

function spawnEnemy(id = null, elite = false) {
  const m = minute();
  const table = m < 1 ? ["murkling", "murkling", "bat"]
    : m < 2 ? ["murkling", "bat", "slug", "imp"]
    : m < 4 ? ["murkling", "bat", "slug", "imp", "wisp", "husk"]
    : ["murkling", "bat", "slug", "imp", "wisp", "husk", "husk"];
  const e = scaledEnemy(id || pick(table), elite);
  const w = canvas.clientWidth;
  const h = canvas.clientHeight;
  const edge = Math.floor(rand() * 4);
  e.x = edge === 0 ? -35 : edge === 1 ? w + 35 : rand() * w;
  e.y = edge === 2 ? -35 : edge === 3 ? h + 35 : rand() * h;
  state.enemies.push(e);
}

function spawnBoss() {
  const boss = scaledEnemy("boss", false);
  boss.hp = 1500;
  boss.maxHp = 1500;
  boss.x = canvas.clientWidth + 60;
  boss.y = canvas.clientHeight * 0.5;
  state.enemies.push(boss);
  state.floaters.push({ text: "MINIBOSS", x: canvas.clientWidth / 2 - 30, y: 90, life: 2 });
}

function inputVector() {
  const x = (keys.d || keys.ArrowRight ? 1 : 0) - (keys.a || keys.ArrowLeft ? 1 : 0);
  const y = (keys.s || keys.ArrowDown ? 1 : 0) - (keys.w || keys.ArrowUp ? 1 : 0);
  const len = Math.hypot(x, y) || 1;
  return { x: x / len, y: y / len };
}

function nearestEnemy(range) {
  let best = null;
  let bestD = range;
  for (const e of state.enemies) {
    const d = dist(state.player, e);
    if (d < bestD) {
      best = e;
      bestD = d;
    }
  }
  return best;
}

function hitEnemy(e, damage, burn = false) {
  const crit = rand() < state.crit ? 1.8 : 1;
  e.hp -= damage * crit;
  if (burn) e.burn = Math.max(e.burn, state.burnTime);
}

function fireWeapon(w) {
  const def = weaponDefs[w.id];
  if (w.id === "bell") {
    state.pulse = 0.18;
    for (const e of state.enemies) {
      if (dist(state.player, e) <= def.range + w.level * 8) hitEnemy(e, w.damage);
    }
    return;
  }
  if (w.id === "spark") {
    const targets = state.enemies
      .filter(e => dist(state.player, e) <= def.range)
      .sort((a, b) => dist(state.player, a) - dist(state.player, b))
      .slice(0, 3 + w.level);
    for (const e of targets) hitEnemy(e, w.damage);
    state.floaters.push({ text: "zap", x: state.player.x + 14, y: state.player.y - 20, life: 0.25 });
    return;
  }
  const target = nearestEnemy(def.range);
  if (!target) return;
  const a = Math.atan2(target.y - state.player.y, target.x - state.player.x);
  state.bullets.push({
    x: state.player.x,
    y: state.player.y,
    vx: Math.cos(a) * def.speed,
    vy: Math.sin(a) * def.speed,
    r: 5,
    life: 1.1,
    damage: w.damage,
    burn: true,
    color: def.color
  });
}

function gainXP(amount) {
  const p = state.player;
  p.xp += amount;
  let needed = 8 + p.level * 5;
  while (p.xp >= needed) {
    p.xp -= needed;
    p.level += 1;
    openUpgrade();
    needed = 8 + p.level * 5;
    break;
  }
}

function openUpgrade() {
  state.choosing = true;
  state.paused = true;
  const choices = [];
  while (choices.length < 3) {
    const u = pick(upgrades);
    if (!choices.includes(u)) choices.push(u);
  }
  ui.upgradeCards.innerHTML = "";
  choices.forEach((u, i) => {
    const card = document.createElement("button");
    card.className = "card";
    card.innerHTML = `<b>${i + 1}. ${u.name}</b><span>${u.desc}</span><small>${u.type}</small>`;
    card.addEventListener("click", () => takeUpgrade(u));
    ui.upgradeCards.appendChild(card);
  });
  ui.upgradeModal.classList.remove("hidden");
}

function takeUpgrade(upgrade) {
  upgrade.apply(state);
  state.choosing = false;
  state.paused = false;
  ui.upgradeModal.classList.add("hidden");
}

function update(dt) {
  state.time += dt;
  const p = state.player;
  const v = inputVector();
  p.x = clamp(p.x + v.x * p.speed * dt, p.r, canvas.clientWidth - p.r);
  p.y = clamp(p.y + v.y * p.speed * dt, p.r, canvas.clientHeight - p.r);

  if (state.time > 120 && state.time - dt <= 120) spawnEnemy("slug", true);
  if (state.time > 300 && state.time - dt <= 300) spawnBoss();

  const maxEnemies = Math.floor(45 + 18 * minute());
  const spawnRate = 1.2 + 0.55 * minute();
  state.spawnCarry += spawnRate * dt;
  while (state.spawnCarry >= 1 && state.enemies.length < maxEnemies) {
    spawnEnemy();
    state.spawnCarry -= 1;
  }

  for (const w of Object.values(state.weapons)) {
    w.cd -= dt;
    if (w.cd <= 0) {
      fireWeapon(w);
      w.cd = weaponDefs[w.id].rate * state.cooldownMult;
    }
  }

  for (const e of state.enemies) {
    const a = Math.atan2(p.y - e.y, p.x - e.x);
    const wobble = e.id === "imp" ? Math.sin(state.time * 7 + e.x) * 0.45 : 0;
    e.x += Math.cos(a + wobble) * e.speed * dt;
    e.y += Math.sin(a + wobble) * e.speed * dt;
    if (e.burn > 0) {
      e.burn -= dt;
      e.hp -= 3 * dt;
    }
    if (dist(p, e) < p.r + e.r) p.hp -= e.dmg * dt;
  }

  for (const b of state.bullets) {
    b.x += b.vx * dt;
    b.y += b.vy * dt;
    b.life -= dt;
    for (const e of state.enemies) {
      if (b.life > 0 && dist(b, e) < b.r + e.r) {
        hitEnemy(e, b.damage, b.burn);
        b.life = 0;
      }
    }
  }

  const dead = [];
  state.enemies = state.enemies.filter(e => {
    if (e.hp > 0) return true;
    dead.push(e);
    return false;
  });
  for (const e of dead) {
    state.kills += 1;
    state.pickups.push({ x: e.x, y: e.y, r: 5, type: "xp", value: e.xp });
    if (state.splitFlint && e.burn > 0) {
      for (const other of state.enemies) if (dist(e, other) < 58) hitEnemy(other, 8);
      state.floaters.push({ text: "boom", x: e.x, y: e.y, life: 0.35 });
    }
    if (e.id === "boss") endRun(true);
  }

  for (const item of state.pickups) {
    if (dist(p, item) < state.pickupRadius) {
      gainXP(item.value);
      item.dead = true;
    }
  }

  state.bullets = state.bullets.filter(b => b.life > 0);
  state.pickups = state.pickups.filter(pickup => !pickup.dead);
  state.floaters = state.floaters.filter(f => (f.life -= dt) > 0);
  state.pulse = Math.max(0, state.pulse - dt);

  if (p.hp <= 0) endRun(false);
}

function drawCircle(x, y, r, color) {
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.arc(x, y, r, 0, Math.PI * 2);
  ctx.fill();
}

function draw() {
  const w = canvas.clientWidth;
  const h = canvas.clientHeight;
  ctx.clearRect(0, 0, w, h);
  ctx.fillStyle = "#121018";
  ctx.fillRect(0, 0, w, h);

  ctx.strokeStyle = "rgba(255,255,255,.055)";
  for (let x = -40; x < w + 40; x += 40) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x + 80, h);
    ctx.stroke();
  }

  for (const item of state.pickups) drawCircle(item.x, item.y, item.r, "#6ee7ff");
  for (const b of state.bullets) drawCircle(b.x, b.y, b.r, b.color);

  for (const e of state.enemies) {
    drawCircle(e.x, e.y, e.r, e.burn > 0 ? "#ff9f43" : e.color);
    if (e.elite || e.id === "boss") {
      ctx.strokeStyle = e.id === "boss" ? "#f5d67b" : "#e86f68";
      ctx.lineWidth = 2;
      ctx.stroke();
    }
  }

  if (state.pulse > 0) {
    ctx.strokeStyle = "rgba(245,214,123,.58)";
    ctx.lineWidth = 5;
    ctx.beginPath();
    ctx.arc(state.player.x, state.player.y, 86, 0, Math.PI * 2);
    ctx.stroke();
  }

  drawCircle(state.player.x, state.player.y, state.player.r, "#f5d67b");
  drawCircle(state.player.x + 5, state.player.y - 3, 4, "#e86f68");

  ctx.font = "12px system-ui";
  ctx.fillStyle = "#f4eff8";
  for (const f of state.floaters) ctx.fillText(f.text, f.x, f.y);
}

function updateUI() {
  const p = state.player;
  const hpPct = clamp(p.hp / p.maxHp, 0, 1);
  const need = 8 + p.level * 5;
  ui.hpBar.style.width = `${hpPct * 100}%`;
  ui.hpText.textContent = `HP ${Math.ceil(Math.max(0, p.hp))} / ${p.maxHp}`;
  ui.xpBar.style.width = `${clamp(p.xp / need, 0, 1) * 100}%`;
  ui.levelText.textContent = `Lv ${p.level}`;
  ui.killText.textContent = `${state.kills} kills`;
  const t = Math.floor(state.time);
  ui.timer.textContent = `${String(Math.floor(t / 60)).padStart(2, "0")}:${String(t % 60).padStart(2, "0")}`;
  ui.waveText.textContent = state.time < 120 ? "Murkling dusk" : state.time < 300 ? "Ash swarm" : "Bell Ghast";
}

function endRun(victory) {
  if (state.over) return;
  state.over = true;
  state.paused = true;
  ui.gameOverTitle.textContent = victory ? "Boss banished" : "The swarm took you";
  ui.gameOverStats.textContent = `Time ${ui.timer.textContent} | Level ${state.player.level} | ${state.kills} kills`;
  ui.gameOver.classList.remove("hidden");
}

function loop(now) {
  const dt = Math.min(0.033, (now - state.last) / 1000 || 0);
  state.last = now;
  if (!state.paused) update(dt);
  draw();
  updateUI();
  requestAnimationFrame(loop);
}

function restart() {
  seed = 20260426;
  state = makeState();
  ui.gameOver.classList.add("hidden");
  ui.upgradeModal.classList.add("hidden");
}

window.addEventListener("keydown", (e) => {
  keys[e.key] = true;
  const n = Number(e.key);
  if (state?.choosing && n >= 1 && n <= 3) {
    const card = ui.upgradeCards.children[n - 1];
    if (card) card.click();
  }
  if (e.key.toLowerCase() === "p" && !state.choosing && !state.over) state.paused = !state.paused;
});
window.addEventListener("keyup", (e) => { keys[e.key] = false; });
window.addEventListener("resize", resize);
ui.restartButton.addEventListener("click", restart);

resize();
restart();
requestAnimationFrame(loop);
