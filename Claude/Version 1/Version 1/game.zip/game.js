/* =============================================================
   EMBERFALL: NIGHTSWARM — vanilla JS prototype
   Single-file implementation. No external assets, no fetch.
   Procedural pixel-art sprites drawn into offscreen canvases
   at boot, then blitted each frame.
   ============================================================= */

(() => {
'use strict';

/* ---------- Palette (matches design doc §12) ---------- */
const PAL = {
  bg0: '#0d0a14', bg1: '#1c1a2b', bg2: '#3a2f4a',
  mauve: '#6b4a7a', pink: '#c98aab',
  cream: '#f3d0a3', amber: '#ffb84a', orange: '#ff6b3d', red: '#d63d2e',
  teal: '#4ac1bd', deepTeal: '#2d6e7e', deeperTeal: '#1a3b4f',
  darkGreen: '#2a5a3d', green: '#6fa86c',
  paper: '#e8e3d6', white: '#ffffff'
};

/* ---------- Seedable RNG (Mulberry32) ---------- */
let _seed = (Date.now() & 0xffffffff) >>> 0;
function seedRng(s) { _seed = (s >>> 0) || 1; }
function rand() {
  _seed = (_seed + 0x6D2B79F5) >>> 0;
  let t = _seed;
  t = Math.imul(t ^ (t >>> 15), t | 1);
  t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
}
const randRange = (a, b) => a + rand() * (b - a);
const randInt = (a, b) => Math.floor(randRange(a, b + 1));
const choice = arr => arr[Math.floor(rand() * arr.length)];
function weightedPick(entries, weightKey = 'weight') {
  let total = 0; for (const e of entries) total += e[weightKey];
  let r = rand() * total;
  for (const e of entries) { r -= e[weightKey]; if (r <= 0) return e; }
  return entries[entries.length - 1];
}

/* =============================================================
   GAME DATA
   ============================================================= */

const CHARACTERS = [
  { id: 'wyck',   name: 'Wyck', flavor: 'Lantern-Keeper of the last flame.',
    starter: 'ember_beam',  passive: { type: 'pickup_radius', value: 0.10 },
    color: PAL.amber },
  { id: 'ferren', name: 'Ferren', flavor: 'Heretic nun who weaponized prayer.',
    starter: 'hymn_wave',   passive: { type: 'weapon_area', value: 0.15 },
    color: PAL.pink },
  { id: 'brom',   name: 'Brom', flavor: 'Drunken smith who throws what he forges.',
    starter: 'anvil_toss',  passive: { type: 'damage', value: 0.20, speedPenalty: 0.10 },
    color: PAL.orange }
];

const ENEMIES = {
  husk:    { name: 'Husk',    hp: 6,  speed: 50, dmg: 4, weight: 100, size: 12, color: PAL.mauve, behavior: 'chase' },
  crawler: { name: 'Crawler', hp: 4,  speed: 80, dmg: 3, weight: 60,  size: 10, color: PAL.pink,  behavior: 'chase' },
  brute:   { name: 'Brute',   hp: 30, speed: 35, dmg: 8, weight: 25,  size: 18, color: PAL.deepTeal, behavior: 'chase' },
  vexbat:  { name: 'Vexbat',  hp: 8,  speed: 90, dmg: 4, weight: 35,  size: 11, color: PAL.teal,  behavior: 'weave' },
  spitter: { name: 'Spitter', hp: 12, speed: 40, dmg: 5, weight: 20,  size: 13, color: PAL.green, behavior: 'ranged' },
  hexer:   { name: 'Hexer',   hp: 20, speed: 30, dmg: 5, weight: 8,   size: 16, color: PAL.orange, behavior: 'aura' }
};

// Boss spawned at fixed time
const BOSSES = {
  marrow: { name: 'Marrow Knight', hp: 600, speed: 40, dmg: 14, size: 28, color: PAL.cream, behavior: 'charge' }
};

// Spawn tables per minute. Index 0 = minute 0..1, etc.
const SPAWN_TABLES = [
  /* 0:00 */ [ ['husk', 100] ],
  /* 1:00 */ [ ['husk', 80], ['crawler', 40] ],
  /* 2:00 */ [ ['husk', 60], ['crawler', 50], ['brute', 25], ['spitter', 15] ],
  /* 3:00 */ [ ['husk', 60], ['crawler', 50], ['brute', 25], ['spitter', 20] ],
  /* 4:00 */ [ ['husk', 50], ['crawler', 40], ['brute', 25], ['spitter', 20], ['vexbat', 30] ],
  /* 5:00 */ [ ['husk', 50], ['crawler', 50], ['brute', 30], ['spitter', 25], ['vexbat', 35], ['hexer', 8] ],
  /* 6:00+*/ [ ['husk', 40], ['crawler', 50], ['brute', 35], ['spitter', 25], ['vexbat', 40], ['hexer', 12] ]
].map(rows => rows.map(([id, weight]) => ({ id, weight })));

const EVENTS = [
  { at: 120, kind: 'boss', boss: 'marrow', fired: false }, // 2:00 miniboss
  { at: 240, kind: 'chest', fired: false },                // 4:00 chest
  { at: 360, kind: 'elite_swarm', fired: false }           // 6:00 elite swarm
];

/* ---------- Weapons ----------
   atkRate is seconds between fires.
   Damage scales +15% per level. */
const WEAPONS = {
  ember_beam: {
    name: 'Ember Beam', icon: '∿', type: 'beam',
    dmg: 4, atkRate: 0.18, range: 220, projSpeed: 800, pierce: 99,
    desc: 'Continuous beam. Pierces all.', tier: 'C'
  },
  hymn_wave: {
    name: 'Hymn Wave', icon: '◯', type: 'aoe_ring',
    dmg: 12, atkRate: 2.4, range: 150, projSpeed: 320, pierce: 99,
    desc: 'Concentric ring. Slows enemies.', tier: 'C'
  },
  anvil_toss: {
    name: 'Anvil Toss', icon: '◧', type: 'projectile',
    dmg: 28, atkRate: 1.4, range: 280, projSpeed: 280, pierce: 0,
    desc: 'Heavy lobbed projectile. Knockback.', tier: 'C'
  },
  thorn_halo: {
    name: 'Thorn Halo', icon: '✦', type: 'orbit',
    dmg: 6, atkRate: 0.15, range: 80, projSpeed: 0, pierce: 99,
    desc: '3 thorns orbit you. Bleed on hit.', tier: 'C'
  },
  shade_daggers: {
    name: 'Shade Daggers', icon: '✕', type: 'projectile_burst',
    dmg: 9, atkRate: 0.7, range: 240, projSpeed: 380, pierce: 0,
    desc: '2 daggers in your facing direction.', tier: 'C', count: 2
  },
  scattershot: {
    name: 'Scattershot Pike', icon: '※', type: 'projectile_burst',
    dmg: 6, atkRate: 1.1, range: 200, projSpeed: 360, pierce: 0,
    desc: '5-pellet cone. 25% crit ×2.', tier: 'C', count: 5, spread: 0.5, critChance: 0.25, critMult: 2.0
  },
  salt_circle: {
    name: 'Salt Circle', icon: '◌', type: 'aura',
    dmg: 3, atkRate: 0.25, range: 110, projSpeed: 0, pierce: 99,
    desc: 'Damaging ring under your feet.', tier: 'U'
  },
  stormnail: {
    name: 'Stormnail', icon: '↯', type: 'homing',
    dmg: 18, atkRate: 0.9, range: 320, projSpeed: 320, pierce: 0,
    desc: 'Homing nail. Light tracking.', tier: 'U'
  }
};

const STARTER_ALLOWED = ['ember_beam','hymn_wave','anvil_toss','thorn_halo','shade_daggers','scattershot'];

/* ---------- Artifacts (one-time pickups) ---------- */
const ARTIFACTS = {
  cracked_lens:    { name: 'Cracked Lens',    desc: '+20% projectile speed.',                tier: 'C', stat: 'projSpeedMul', value: 1.20 },
  old_bandolier:   { name: 'Old Bandolier',   desc: '+1 projectile to burst weapons.',       tier: 'U', stat: 'projCountAdd', value: 1 },
  wickwax_tin:     { name: 'Wickwax Tin',     desc: '+25% weapon area.',                     tier: 'C', stat: 'areaMul',      value: 1.25 },
  iron_heel:       { name: 'Iron Heel',       desc: '+15% move speed.',                      tier: 'C', stat: 'moveSpeedMul', value: 1.15 },
  greedy_heart:    { name: 'Greedy Heart',    desc: '+50% pickup radius.',                   tier: 'C', stat: 'pickupRadMul', value: 1.50 },
  pale_coin:       { name: 'Pale Coin',       desc: '+20% ember (XP) gained.',               tier: 'U', stat: 'xpMul',        value: 1.20 },
  iron_lung:       { name: 'Iron Lung',       desc: '+25 max HP, fully healed.',             tier: 'C', stat: 'maxHpAdd',     value: 25 },
  marrow_charm:    { name: 'Marrow Charm',    desc: '+15% crit chance, +25% crit dmg.',      tier: 'R', stat: 'critBundle',   value: 1 },
  fractured_hourglass: { name: 'Fractured Hourglass', desc: '−15% all weapon cooldowns.',    tier: 'R', stat: 'cdMul',        value: 0.85 },
  splinter_lodestone:  { name: 'Splinter Lodestone',  desc: 'Projectiles pierce +1.',        tier: 'U', stat: 'pierceAdd',    value: 1 }
};

/* =============================================================
   GLOBAL STATE
   ============================================================= */
const W = 960, H = 640;          // canvas internal resolution
const VIEW_R = 640;              // off-screen spawn ring radius (just past corners)
const TILE = 64;
const cnv = document.getElementById('game');
const ctx = cnv.getContext('2d');
ctx.imageSmoothingEnabled = false;

const mini = document.getElementById('minimap');
const mctx = mini.getContext('2d');
mctx.imageSmoothingEnabled = false;

const META_KEY = 'emberfall_meta_v1';

const META_DEFAULT = {
  shards: 0,
  upgrades: { hp: 0, dmg: 0, speed: 0, xp: 0 }, // tier counts
  victories: 0,
  bestTime: 0
};

const SHOP_DEFS = [
  { id: 'hp',    name: 'Iron Lung',     stat: '+10 max HP / tier',    max: 10, costFn: t => 50 * (t + 1) },
  { id: 'dmg',   name: 'Honed Edge',    stat: '+3% damage / tier',    max: 15, costFn: t => 60 * (t + 1) },
  { id: 'speed', name: 'Quick Step',    stat: '+2% move speed / tier',max: 10, costFn: t => 70 * (t + 1) },
  { id: 'xp',    name: 'Hungering Eye', stat: '+3% XP / tier',        max: 10, costFn: t => 80 * (t + 1) }
];

let meta = loadMeta();

const game = {
  running: false,
  paused: false,
  ended: false,
  cardOpen: false,
  t: 0,                     // run time (s)
  killCount: 0,
  emberCount: 0,
  shardsThisRun: 0,
  charDef: null,
  player: null,
  enemies: [],
  bullets: [],
  pickups: [],
  particles: [],
  floats: [],
  events: [],
  cam: { x: 0, y: 0 },
  inputDir: { x: 0, y: 0 },
  facing: { x: 1, y: 0 },
  pendingBoss: null,
  spawnAccum: 0
};

/* =============================================================
   PROCEDURAL SPRITES
   ============================================================= */
const SPRITES = {};

function makeCanvas(w, h) {
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  return c;
}
function px(c, x, y, color) {
  const g = c.getContext('2d');
  g.fillStyle = color;
  g.fillRect(x, y, 1, 1);
}
function rect(c, x, y, w, h, color) {
  const g = c.getContext('2d');
  g.fillStyle = color;
  g.fillRect(x, y, w, h);
}

/* Build sprites once at boot. Each character/enemy is a small canvas. */
function buildSprites() {
  // Characters (16x20)
  for (const ch of CHARACTERS) {
    const c = makeCanvas(16, 20);
    // Cape / body
    rect(c, 4, 6, 8, 10, ch.color);
    rect(c, 5, 5, 6, 1, ch.color);
    // Head
    rect(c, 5, 2, 6, 4, PAL.cream);
    // Eyes
    px(c, 6, 4, PAL.bg0); px(c, 9, 4, PAL.bg0);
    // Hood/hat shadow
    rect(c, 5, 1, 6, 1, PAL.bg2);
    // Belt
    rect(c, 4, 11, 8, 1, PAL.bg2);
    // Boots
    rect(c, 4, 16, 3, 3, PAL.bg2);
    rect(c, 9, 16, 3, 3, PAL.bg2);
    // Lantern / weapon hint
    if (ch.id === 'wyck')  { rect(c, 12, 9, 3, 4, PAL.amber); px(c, 13, 8, PAL.cream); }
    if (ch.id === 'ferren'){ rect(c, 0,  9, 3, 4, PAL.pink); px(c, 1, 8, PAL.cream); }
    if (ch.id === 'brom')  { rect(c, 12, 9, 3, 3, PAL.bg2); rect(c, 11, 9, 1, 3, PAL.bg2); }
    SPRITES['char_' + ch.id] = c;
  }

  // Enemies — simple silhouettes
  function enemySprite(size, body, accent, eye = PAL.red) {
    const c = makeCanvas(size, size);
    const m = Math.floor(size / 8);
    rect(c, m, m, size - 2 * m, size - 2 * m, body);
    rect(c, m + 1, m + 1, size - 2 * m - 2, 1, accent);
    // eyes
    px(c, Math.floor(size / 3), Math.floor(size / 2) - 1, eye);
    px(c, Math.floor(size * 2 / 3) - 1, Math.floor(size / 2) - 1, eye);
    // legs
    rect(c, m, size - m, 2, m, PAL.bg2);
    rect(c, size - m - 2, size - m, 2, m, PAL.bg2);
    return c;
  }
  SPRITES.enemy_husk    = enemySprite(16, PAL.mauve,    PAL.bg2,     PAL.red);
  SPRITES.enemy_crawler = enemySprite(14, PAL.pink,     PAL.mauve,   PAL.red);
  SPRITES.enemy_brute   = enemySprite(22, PAL.deepTeal, PAL.deeperTeal, PAL.amber);
  SPRITES.enemy_vexbat  = enemySprite(14, PAL.teal,     PAL.deepTeal, PAL.cream);
  SPRITES.enemy_spitter = enemySprite(16, PAL.green,    PAL.darkGreen, PAL.amber);
  SPRITES.enemy_hexer   = enemySprite(20, PAL.orange,   PAL.red,     PAL.cream);

  // Boss — bigger, ornate
  {
    const c = makeCanvas(36, 36);
    rect(c, 6, 8, 24, 24, PAL.cream);
    rect(c, 8, 6, 20, 4, PAL.bg2);
    rect(c, 6, 12, 24, 2, PAL.amber);
    rect(c, 12, 18, 4, 4, PAL.red);
    rect(c, 20, 18, 4, 4, PAL.red);
    rect(c, 14, 26, 8, 2, PAL.bg2);
    SPRITES.boss_marrow = c;
  }

  // Pickups
  {
    const c = makeCanvas(8, 8);
    rect(c, 2, 2, 4, 4, PAL.teal);
    rect(c, 3, 1, 2, 1, PAL.cream);
    rect(c, 3, 6, 2, 1, PAL.deepTeal);
    SPRITES.pickup_ember = c;
  }
  {
    const c = makeCanvas(10, 10);
    rect(c, 3, 3, 4, 4, PAL.amber);
    rect(c, 2, 4, 1, 2, PAL.cream);
    rect(c, 7, 4, 1, 2, PAL.cream);
    rect(c, 4, 2, 2, 1, PAL.cream);
    SPRITES.pickup_gold = c;
  }
  {
    const c = makeCanvas(10, 10);
    rect(c, 3, 4, 4, 3, PAL.red);
    rect(c, 4, 3, 2, 1, PAL.red);
    rect(c, 3, 3, 1, 1, PAL.pink);
    SPRITES.pickup_heart = c;
  }
  {
    const c = makeCanvas(12, 12);
    rect(c, 2, 4, 8, 6, PAL.bg2);
    rect(c, 2, 3, 8, 1, PAL.amber);
    rect(c, 5, 6, 2, 2, PAL.amber);
    SPRITES.pickup_chest = c;
  }

  // Tile
  {
    const c = makeCanvas(TILE, TILE);
    const g = c.getContext('2d');
    g.fillStyle = PAL.bg1; g.fillRect(0, 0, TILE, TILE);
    // cobble specks
    for (let i = 0; i < 18; i++) {
      const x = Math.floor(rand() * TILE), y = Math.floor(rand() * TILE);
      g.fillStyle = rand() < 0.5 ? PAL.bg2 : PAL.deeperTeal;
      g.fillRect(x, y, 2, 2);
    }
    // cracks
    g.fillStyle = PAL.bg0;
    g.fillRect(0, 0, TILE, 1); g.fillRect(0, 0, 1, TILE);
    SPRITES.tile = c;
  }
}

/* =============================================================
   META / SAVE
   ============================================================= */
function loadMeta() {
  try {
    const raw = localStorage.getItem(META_KEY);
    if (!raw) return structuredClone(META_DEFAULT);
    const parsed = JSON.parse(raw);
    return Object.assign(structuredClone(META_DEFAULT), parsed);
  } catch (e) {
    return structuredClone(META_DEFAULT);
  }
}
function saveMeta() {
  try { localStorage.setItem(META_KEY, JSON.stringify(meta)); } catch (e) {}
}

/* =============================================================
   INPUT
   ============================================================= */
const keys = new Set();
window.addEventListener('keydown', e => {
  keys.add(e.key.toLowerCase());
  if (e.key === 'p' || e.key === 'P') togglePause();
  if (game.cardOpen && (e.key === '1' || e.key === '2' || e.key === '3')) {
    const idx = parseInt(e.key, 10) - 1;
    pickCard(idx);
  }
});
window.addEventListener('keyup', e => keys.delete(e.key.toLowerCase()));

function readInput() {
  let x = 0, y = 0;
  if (keys.has('a') || keys.has('arrowleft'))  x -= 1;
  if (keys.has('d') || keys.has('arrowright')) x += 1;
  if (keys.has('w') || keys.has('arrowup'))    y -= 1;
  if (keys.has('s') || keys.has('arrowdown'))  y += 1;
  const m = Math.hypot(x, y) || 1;
  return { x: x / m, y: y / m, mag: Math.hypot(x, y) };
}

/* =============================================================
   SCALING FORMULAS  (design doc §9)
   ============================================================= */
function scaleHP(base, t)  { const m = t / 60; return base * (1 + 0.18 * m + 0.04 * Math.pow(m, 1.6)); }
function scaleDmg(base, t) { return base * (1 + 0.10 * (t / 60)); }
function rateMul(t)        { return 1 + 0.25 * (t / 60); }

/* =============================================================
   START / END RUN
   ============================================================= */
function startRun(charId) {
  const ch = CHARACTERS.find(c => c.id === charId) || CHARACTERS[0];
  game.charDef = ch;

  // Player base, with meta upgrades
  const hpBonus  = meta.upgrades.hp * 10;
  const dmgBonus = meta.upgrades.dmg * 0.03;
  const spdBonus = meta.upgrades.speed * 0.02;
  const xpBonus  = meta.upgrades.xp * 0.03;

  const baseHp = 100 + hpBonus;
  game.player = {
    x: 0, y: 0,
    hp: baseHp, maxHp: baseHp,
    speed: 140 * (1 + spdBonus) * (ch.passive.type === 'damage' ? (1 - (ch.passive.speedPenalty || 0)) : 1),
    pickupRad: 38,
    weapons: [{ id: ch.starter, lvl: 1, cd: 0, phase: 0 }],
    artifacts: [],
    level: 1, xp: 0, xpToNext: 5,
    hurtFlash: 0,
    invuln: 0,
    iframeOnLevel: 0,
    // Stat modifiers (start defaults)
    mods: {
      damageMul: 1 + dmgBonus + (ch.passive.type === 'damage' ? ch.passive.value : 0),
      areaMul:  1 + (ch.passive.type === 'weapon_area' ? ch.passive.value : 0),
      cdMul: 1.0,
      projSpeedMul: 1.0,
      projCountAdd: 0,
      pierceAdd: 0,
      pickupRadMul: 1 + (ch.passive.type === 'pickup_radius' ? ch.passive.value : 0),
      moveSpeedMul: 1.0,
      xpMul: 1 + xpBonus,
      maxHpAdd: 0,
      critChance: 0,
      critMult: 1.5
    }
  };
  // apply pickup radius mod
  game.player.pickupRad *= game.player.mods.pickupRadMul;

  game.t = 0;
  game.killCount = 0;
  game.emberCount = 0;
  game.shardsThisRun = 0;
  game.enemies = [];
  game.bullets = [];
  game.pickups = [];
  game.particles = [];
  game.floats = [];
  game.cam = { x: 0, y: 0 };
  game.events = EVENTS.map(e => ({ ...e, fired: false }));
  game.spawnAccum = 0;
  game.running = true;
  game.paused = false;
  game.ended = false;
  game.cardOpen = false;

  hideOverlay('title-overlay');
  hideOverlay('end-overlay');
  hideOverlay('card-overlay');
  document.getElementById('hud').style.visibility = 'visible';
  document.getElementById('char-name').textContent = ch.name;
}

function endRun(victory) {
  if (game.ended) return;
  game.ended = true;
  game.running = false;

  // Award shards
  meta.shards += game.shardsThisRun;
  if (victory) meta.victories++;
  if (game.t > meta.bestTime) meta.bestTime = game.t;
  saveMeta();

  // Show end overlay
  document.getElementById('end-title').textContent = victory
    ? 'You held the night.'
    : 'You fell to the night.';
  const stats = document.getElementById('end-stats');
  stats.innerHTML = `
    <span class="k">Time</span><span>${fmtTime(game.t)}</span>
    <span class="k">Level</span><span>${game.player.level}</span>
    <span class="k">Kills</span><span>${game.killCount}</span>
    <span class="k">Embers</span><span>${game.emberCount}</span>
    <span class="k">Shards Earned</span><span>★ ${game.shardsThisRun}</span>
    <span class="k">Total Shards</span><span>★ ${meta.shards}</span>`;
  showOverlay('end-overlay');
}

/* =============================================================
   SPAWNING
   ============================================================= */
function currentSpawnTable() {
  const m = Math.min(Math.floor(game.t / 60), SPAWN_TABLES.length - 1);
  return SPAWN_TABLES[m];
}

function spawnEnemyAtRing(typeId, isElite = false) {
  const def = ENEMIES[typeId];
  if (!def) return;
  const ang = rand() * Math.PI * 2;
  const r = VIEW_R + randRange(-30, 30);
  const x = game.player.x + Math.cos(ang) * r;
  const y = game.player.y + Math.sin(ang) * r;
  const hpMul = isElite ? 5 : 1;
  const dmgMul = isElite ? 1.3 : 1;
  game.enemies.push({
    type: typeId,
    x, y, vx: 0, vy: 0,
    hp: scaleHP(def.hp, game.t) * hpMul,
    maxHp: scaleHP(def.hp, game.t) * hpMul,
    dmg: scaleDmg(def.dmg, game.t) * dmgMul,
    speed: def.speed,
    size: def.size,
    color: def.color,
    elite: isElite,
    phase: rand() * Math.PI * 2,
    cooldown: 0,
    knockback: { x: 0, y: 0 }
  });
}

function spawnBoss(bossId) {
  const def = BOSSES[bossId];
  if (!def) return;
  const ang = rand() * Math.PI * 2;
  const r = VIEW_R + 60;
  game.enemies.push({
    type: 'boss_' + bossId,
    boss: true,
    bossId,
    x: game.player.x + Math.cos(ang) * r,
    y: game.player.y + Math.sin(ang) * r,
    vx: 0, vy: 0,
    hp: def.hp * (1 + 0.05 * (game.t / 60)),
    maxHp: def.hp * (1 + 0.05 * (game.t / 60)),
    dmg: def.dmg,
    speed: def.speed,
    size: def.size,
    color: def.color,
    phase: 0, cooldown: 2,
    knockback: { x: 0, y: 0 }
  });
  pushFloat(game.player.x, game.player.y - 60, def.name + ' approaches!', PAL.amber, 2.0);
}

function spawnTick(dt) {
  // Spawn budget
  const baseRate = 1.6; // base enemies per second
  const budget = baseRate * rateMul(game.t) * dt;
  game.spawnAccum += budget;

  const cap = Math.floor(40 + 12 * (game.t / 60));
  const table = currentSpawnTable();

  while (game.spawnAccum >= 1) {
    if (game.enemies.length >= cap) { game.spawnAccum = 0; break; }
    const pick = weightedPick(table);
    const elite = game.t > 180 && rand() < (game.t > 420 ? 0.03 : 0.01);
    spawnEnemyAtRing(pick.id, elite);
    game.spawnAccum -= 1;
  }

  // Events
  for (const ev of game.events) {
    if (!ev.fired && game.t >= ev.at) {
      ev.fired = true;
      if (ev.kind === 'boss') spawnBoss(ev.boss);
      if (ev.kind === 'chest') {
        const ang = rand() * Math.PI * 2; const r = 220;
        game.pickups.push({ kind: 'chest', x: game.player.x + Math.cos(ang) * r, y: game.player.y + Math.sin(ang) * r, life: 9999 });
        pushFloat(game.player.x, game.player.y - 60, 'A chest shimmers nearby.', PAL.amber, 1.6);
      }
      if (ev.kind === 'elite_swarm') {
        for (let i = 0; i < 10; i++) spawnEnemyAtRing('husk', true);
        pushFloat(game.player.x, game.player.y - 60, 'Elite swarm!', PAL.orange, 1.6);
      }
    }
  }
}

/* =============================================================
   WEAPON FIRING
   ============================================================= */
function fireWeapons(dt) {
  for (const w of game.player.weapons) {
    const def = WEAPONS[w.id];
    if (!def) continue;
    const cdMul = game.player.mods.cdMul;
    w.cd -= dt;
    w.phase += dt;

    // Orbits update every frame regardless of cd
    if (def.type === 'orbit') {
      // Orbit weapons don't fire as discrete shots; they're handled in updateBullets
      // We keep persistent thorn entities so check for missing ones.
      ensureOrbits(w);
      continue;
    }
    if (def.type === 'aura') {
      if (w.cd > 0) continue;
      // Aura damages all enemies within range
      const range = def.range * game.player.mods.areaMul;
      for (const e of game.enemies) {
        const dx = e.x - game.player.x, dy = e.y - game.player.y;
        if (dx * dx + dy * dy <= range * range) {
          applyHit(e, scaledDamage(def.dmg, w.lvl), false);
        }
      }
      w.cd = def.atkRate * cdMul;
      continue;
    }

    if (w.cd > 0) continue;
    w.cd = def.atkRate * cdMul;

    if (def.type === 'beam') {
      const tgt = nearestEnemy(game.player.x, game.player.y, def.range);
      if (!tgt) continue;
      const ang = Math.atan2(tgt.y - game.player.y, tgt.x - game.player.x);
      // Beam = thin fast projectile that pierces all
      game.bullets.push(makeBullet({
        x: game.player.x, y: game.player.y, ang,
        speed: def.projSpeed * game.player.mods.projSpeedMul,
        dmg: scaledDamage(def.dmg, w.lvl),
        life: def.range / def.projSpeed,
        pierce: 99, kind: 'beam', size: 4, color: PAL.amber
      }));
    }
    else if (def.type === 'aoe_ring') {
      const radius = def.range * game.player.mods.areaMul;
      // Expanding ring entity
      game.bullets.push({
        kind: 'ring',
        x: game.player.x, y: game.player.y,
        r: 12, rMax: radius,
        speed: def.projSpeed,
        dmg: scaledDamage(def.dmg, w.lvl),
        life: 0.7,
        hit: new Set(),
        color: PAL.pink
      });
    }
    else if (def.type === 'projectile') {
      const tgt = nearestEnemy(game.player.x, game.player.y, def.range);
      const ang = tgt
        ? Math.atan2(tgt.y - game.player.y, tgt.x - game.player.x)
        : Math.atan2(game.facing.y, game.facing.x);
      game.bullets.push(makeBullet({
        x: game.player.x, y: game.player.y, ang,
        speed: def.projSpeed * game.player.mods.projSpeedMul,
        dmg: scaledDamage(def.dmg, w.lvl),
        life: def.range / def.projSpeed,
        pierce: def.pierce + game.player.mods.pierceAdd,
        kind: 'anvil', size: 8, color: PAL.bg2,
        knockback: 200
      }));
    }
    else if (def.type === 'projectile_burst') {
      const count = (def.count || 1) + game.player.mods.projCountAdd;
      const baseAng = (def.spread)
        ? Math.atan2(game.facing.y, game.facing.x)
        : (() => { const t = nearestEnemy(game.player.x, game.player.y, def.range);
                   return t ? Math.atan2(t.y - game.player.y, t.x - game.player.x)
                            : Math.atan2(game.facing.y, game.facing.x); })();
      const spread = def.spread || 0.2;
      for (let i = 0; i < count; i++) {
        const ang = baseAng + (count > 1 ? (i / (count - 1) - 0.5) * spread : 0);
        let dmg = scaledDamage(def.dmg, w.lvl);
        let crit = false;
        const cc = (def.critChance || 0) + game.player.mods.critChance;
        if (rand() < cc) { dmg *= (def.critMult || game.player.mods.critMult); crit = true; }
        game.bullets.push(makeBullet({
          x: game.player.x, y: game.player.y, ang,
          speed: def.projSpeed * game.player.mods.projSpeedMul,
          dmg, life: def.range / def.projSpeed,
          pierce: def.pierce + game.player.mods.pierceAdd,
          kind: 'dagger', size: 5, color: crit ? PAL.amber : PAL.cream
        }));
      }
    }
    else if (def.type === 'homing') {
      const tgt = nearestEnemy(game.player.x, game.player.y, def.range);
      if (!tgt) { w.cd = 0.2; continue; }
      const ang = Math.atan2(tgt.y - game.player.y, tgt.x - game.player.x);
      game.bullets.push(makeBullet({
        x: game.player.x, y: game.player.y, ang,
        speed: def.projSpeed * game.player.mods.projSpeedMul,
        dmg: scaledDamage(def.dmg, w.lvl),
        life: def.range / def.projSpeed * 1.4,
        pierce: def.pierce + game.player.mods.pierceAdd,
        kind: 'homing', size: 6, color: PAL.teal,
        homingTarget: tgt
      }));
    }
  }

  // Update orbits each frame
  updateOrbits(dt);
}

function ensureOrbits(weaponInst) {
  const def = WEAPONS[weaponInst.id];
  const desired = 3 + Math.floor((weaponInst.lvl - 1) / 2); // 3, 3, 4, 4, 5, 5, 6, 6
  // Count existing orbit bullets owned by this weapon
  let count = 0;
  for (const b of game.bullets) if (b.kind === 'orbit' && b.weaponId === weaponInst.id) count++;
  for (let i = count; i < desired; i++) {
    game.bullets.push({
      kind: 'orbit', weaponId: weaponInst.id,
      angOff: (i / desired) * Math.PI * 2,
      r: def.range * game.player.mods.areaMul,
      speed: 3.0,
      dmg: scaledDamage(def.dmg, weaponInst.lvl),
      hitMap: new Map(),
      x: 0, y: 0, life: 9999, size: 6, color: PAL.green
    });
  }
}
function updateOrbits(dt) {
  // Orbits handled within updateBullets render+collision
}

function scaledDamage(baseDmg, lvl) {
  return baseDmg * (1 + 0.15 * (lvl - 1)) * game.player.mods.damageMul;
}

function makeBullet(o) {
  return Object.assign({
    x: 0, y: 0, ang: 0, speed: 0, dmg: 0,
    life: 0.5, pierce: 0, kind: 'beam', size: 3, color: PAL.amber,
    hit: new Set(), knockback: 0
  }, o);
}

function nearestEnemy(x, y, maxR) {
  let best = null, bestD2 = (maxR || 1e9) * (maxR || 1e9);
  for (const e of game.enemies) {
    const dx = e.x - x, dy = e.y - y;
    const d2 = dx * dx + dy * dy;
    if (d2 < bestD2) { bestD2 = d2; best = e; }
  }
  return best;
}

/* =============================================================
   COLLISION / HITS
   ============================================================= */
function applyHit(enemy, dmg, fromBullet) {
  enemy.hp -= dmg;
  pushFloat(enemy.x, enemy.y - 6, Math.round(dmg).toString(),
    dmg >= 50 ? PAL.amber : PAL.cream, 0.6);
  for (let i = 0; i < 3; i++) {
    game.particles.push({
      x: enemy.x, y: enemy.y,
      vx: randRange(-60, 60), vy: randRange(-60, 60),
      life: 0.3, color: enemy.color
    });
  }
  if (enemy.hp <= 0) killEnemy(enemy);
}

function killEnemy(enemy) {
  enemy.dead = true;
  game.killCount++;
  // Drops
  if (enemy.boss) {
    // Boss drops chest + heart + 5 shards + 3 gold
    spawnPickup('chest', enemy.x, enemy.y);
    spawnPickup('heart', enemy.x + 14, enemy.y);
    for (let i = 0; i < 3; i++) {
      const a = rand() * Math.PI * 2;
      spawnPickup('gold', enemy.x + Math.cos(a) * 12, enemy.y + Math.sin(a) * 12);
    }
    game.shardsThisRun += 5;
    pushFloat(enemy.x, enemy.y - 30, '+5 ★', PAL.amber, 1.4);
  } else {
    if (rand() < (enemy.elite ? 1.0 : 0.85)) {
      spawnPickup(enemy.elite ? 'gold' : 'ember', enemy.x, enemy.y);
    }
    if (rand() < 0.01) spawnPickup('heart', enemy.x, enemy.y);
    if (rand() < (enemy.elite ? 0.5 : 0.005)) game.shardsThisRun++;
  }
  // Death burst
  for (let i = 0; i < 8; i++) {
    game.particles.push({
      x: enemy.x, y: enemy.y,
      vx: randRange(-100, 100), vy: randRange(-100, 100),
      life: 0.5, color: enemy.color
    });
  }
}

function spawnPickup(kind, x, y) {
  game.pickups.push({ kind, x, y, life: 60, vx: randRange(-30, 30), vy: randRange(-50, -10) });
}

/* =============================================================
   UPDATE
   ============================================================= */
function update(dt) {
  if (!game.running || game.paused || game.cardOpen) return;
  game.t += dt;

  // Player movement
  const inp = readInput();
  if (inp.mag > 0) { game.facing.x = inp.x; game.facing.y = inp.y; }
  game.player.x += inp.x * game.player.speed * game.player.mods.moveSpeedMul * dt;
  game.player.y += inp.y * game.player.speed * game.player.mods.moveSpeedMul * dt;

  // Camera follows player
  game.cam.x = game.player.x;
  game.cam.y = game.player.y;

  // Hurt flash decay
  game.player.hurtFlash = Math.max(0, game.player.hurtFlash - dt);
  game.player.invuln = Math.max(0, game.player.invuln - dt);

  // Spawn director
  spawnTick(dt);

  // Fire weapons
  fireWeapons(dt);

  // Update enemies
  for (const e of game.enemies) {
    let tx = game.player.x, ty = game.player.y;
    const def = ENEMIES[e.type] || (e.boss ? BOSSES[e.bossId] : null);
    e.phase += dt;

    if (def && def.behavior === 'weave') {
      const sway = Math.sin(e.phase * 4) * 30;
      tx += -Math.sin(e.phase * 0.5) * sway;
      ty += Math.cos(e.phase * 0.5) * sway;
    }
    if (def && def.behavior === 'ranged') {
      const distToPlayer = Math.hypot(e.x - game.player.x, e.y - game.player.y);
      if (distToPlayer < 220) {
        // back away slightly
        tx = e.x - (game.player.x - e.x);
        ty = e.y - (game.player.y - e.y);
      }
      e.cooldown -= dt;
      if (e.cooldown <= 0 && distToPlayer < 260) {
        e.cooldown = 2.2;
        const ang = Math.atan2(game.player.y - e.y, game.player.x - e.x);
        game.bullets.push({
          x: e.x, y: e.y, ang,
          vx: Math.cos(ang) * 180, vy: Math.sin(ang) * 180,
          speed: 180, dmg: e.dmg,
          life: 2.5, pierce: 0, kind: 'enemy_bolt',
          size: 4, color: PAL.green, isEnemy: true,
          hit: new Set()
        });
      }
    }

    const dx = tx - e.x, dy = ty - e.y;
    const m = Math.hypot(dx, dy) || 1;
    e.vx = (dx / m) * e.speed;
    e.vy = (dy / m) * e.speed;
    e.x += (e.vx + e.knockback.x) * dt;
    e.y += (e.vy + e.knockback.y) * dt;
    e.knockback.x *= 0.85; e.knockback.y *= 0.85;

    // Touch damage — flat per-contact, gated by 0.4s invuln window
    if (game.player.invuln <= 0) {
      const ddx = e.x - game.player.x, ddy = e.y - game.player.y;
      const reach = (e.size / 2) + 8;
      if (ddx * ddx + ddy * ddy < reach * reach) {
        damagePlayer(e.dmg);
      }
    }
  }

  // Update bullets
  for (const b of game.bullets) {
    if (b.kind === 'orbit') {
      b.angOff += b.speed * dt;
      b.x = game.player.x + Math.cos(b.angOff) * b.r;
      b.y = game.player.y + Math.sin(b.angOff) * b.r;
      // Hit cooldown per enemy
      for (const e of game.enemies) {
        if (e.dead) continue;
        const dx = e.x - b.x, dy = e.y - b.y;
        const d2 = dx * dx + dy * dy;
        const reach = (e.size / 2) + b.size;
        if (d2 < reach * reach) {
          const last = b.hitMap.get(e) || -1;
          if (game.t - last > 0.4) {
            applyHit(e, b.dmg, true);
            b.hitMap.set(e, game.t);
          }
        }
      }
      continue;
    }
    if (b.kind === 'ring') {
      b.r += b.speed * dt;
      b.life -= dt;
      for (const e of game.enemies) {
        if (e.dead || b.hit.has(e)) continue;
        const dx = e.x - b.x, dy = e.y - b.y;
        const d = Math.hypot(dx, dy);
        if (Math.abs(d - b.r) < 14) {
          applyHit(e, b.dmg, true);
          b.hit.add(e);
        }
      }
      continue;
    }

    if (b.kind === 'homing' && b.homingTarget && !b.homingTarget.dead) {
      const tx = b.homingTarget.x - b.x, ty = b.homingTarget.y - b.y;
      const targetAng = Math.atan2(ty, tx);
      // Smoothly steer
      let da = targetAng - b.ang;
      while (da > Math.PI) da -= Math.PI * 2;
      while (da < -Math.PI) da += Math.PI * 2;
      b.ang += Math.max(-3, Math.min(3, da)) * dt;
    }

    const vx = (b.vx != null) ? b.vx : Math.cos(b.ang) * b.speed;
    const vy = (b.vy != null) ? b.vy : Math.sin(b.ang) * b.speed;
    b.x += vx * dt;
    b.y += vy * dt;
    b.life -= dt;

    if (b.isEnemy) {
      // Enemy bullets damage player only
      if (game.player.invuln <= 0) {
        const dx = game.player.x - b.x, dy = game.player.y - b.y;
        if (dx * dx + dy * dy < 12 * 12) {
          damagePlayer(b.dmg);
          b.life = 0;
        }
      }
      continue;
    }

    // Player bullets damage enemies
    for (const e of game.enemies) {
      if (e.dead || b.hit.has(e)) continue;
      const reach = (e.size / 2) + b.size;
      const dx = e.x - b.x, dy = e.y - b.y;
      if (dx * dx + dy * dy < reach * reach) {
        applyHit(e, b.dmg, true);
        b.hit.add(e);
        if (b.knockback) {
          const pdx = e.x - game.player.x, pdy = e.y - game.player.y;
          const pm = Math.hypot(pdx, pdy) || 1;
          e.knockback.x = (pdx / pm) * b.knockback;
          e.knockback.y = (pdy / pm) * b.knockback;
        }
        if (b.pierce-- <= 0) { b.life = 0; break; }
      }
    }
  }

  // Update pickups
  const pr = game.player.pickupRad;
  for (const p of game.pickups) {
    if (p.kind === 'chest') {
      // Stationary
      p.life -= dt;
    } else {
      p.vy += 100 * dt; // gravity-ish
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.vx *= 0.9; p.vy *= 0.9;
      p.life -= dt;
    }
    const dx = game.player.x - p.x, dy = game.player.y - p.y;
    const d2 = dx * dx + dy * dy;
    const grabR = (p.kind === 'chest') ? 16 : pr;
    if (d2 < grabR * grabR) {
      // Magnetize then collect
      const m = Math.hypot(dx, dy) || 1;
      p.vx = (dx / m) * 320;
      p.vy = (dy / m) * 320;
      if (d2 < 12 * 12) collectPickup(p);
    }
  }

  // Update particles
  for (const pa of game.particles) {
    pa.x += pa.vx * dt; pa.y += pa.vy * dt;
    pa.vx *= 0.92; pa.vy *= 0.92;
    pa.life -= dt;
  }
  // Update floats
  for (const f of game.floats) {
    f.y -= 24 * dt;
    f.life -= dt;
  }

  // Cull
  game.enemies = game.enemies.filter(e => !e.dead && Math.hypot(e.x - game.player.x, e.y - game.player.y) < VIEW_R * 2);
  game.bullets = game.bullets.filter(b => b.life > 0 && (b.kind === 'orbit' || Math.hypot(b.x - game.player.x, b.y - game.player.y) < VIEW_R * 1.4));
  game.pickups = game.pickups.filter(p => !p.taken && p.life > 0);
  game.particles = game.particles.filter(p => p.life > 0);
  game.floats = game.floats.filter(f => f.life > 0);

  // Win condition
  if (game.t >= 600 /* 10 minutes for prototype */) {
    endRun(true);
  }
}

function damagePlayer(amount) {
  if (amount <= 0) return;
  game.player.hp -= amount;
  game.player.hurtFlash = 0.18;
  game.player.invuln = 0.4;
  if (game.player.hp <= 0) {
    game.player.hp = 0;
    endRun(false);
  }
}

function collectPickup(p) {
  if (p.taken) return;
  p.taken = true;
  if (p.kind === 'ember') {
    const v = 1 * game.player.mods.xpMul;
    game.player.xp += v;
    game.emberCount += 1;
    while (game.player.xp >= game.player.xpToNext) levelUp();
  } else if (p.kind === 'gold') {
    const v = 5 * game.player.mods.xpMul;
    game.player.xp += v;
    game.emberCount += 5;
    while (game.player.xp >= game.player.xpToNext) levelUp();
  } else if (p.kind === 'heart') {
    game.player.hp = Math.min(game.player.maxHp, game.player.hp + 20);
    pushFloat(game.player.x, game.player.y - 20, '+20 HP', PAL.red, 0.8);
  } else if (p.kind === 'chest') {
    // Grant a level (and force one card)
    game.player.xp = game.player.xpToNext - 0.001;
    levelUp();
  }
}

/* =============================================================
   LEVEL-UP CARDS
   ============================================================= */
function levelUp() {
  game.player.xp -= game.player.xpToNext;
  game.player.level++;
  game.player.xpToNext = Math.floor(5 * Math.pow(1.12, game.player.level));
  pushFloat(game.player.x, game.player.y - 30, 'LEVEL UP', PAL.amber, 1.0);

  // Build card pool
  const pool = [];

  // Existing weapon upgrades
  for (const w of game.player.weapons) {
    if (w.lvl < 8) {
      pool.push({
        type: 'weapon_lvl', weaponId: w.id, rarity: 'C',
        title: WEAPONS[w.id].name + ' Lv ' + (w.lvl + 1),
        tag: 'Upgrade',
        desc: '+15% damage. Refines effect.'
      });
    }
  }
  // New weapons (up to 6 active)
  if (game.player.weapons.length < 6) {
    const owned = new Set(game.player.weapons.map(w => w.id));
    for (const id of Object.keys(WEAPONS)) {
      if (owned.has(id)) continue;
      const def = WEAPONS[id];
      pool.push({
        type: 'weapon_new', weaponId: id, rarity: def.tier,
        title: def.name, tag: 'New Weapon', desc: def.desc
      });
    }
  }
  // New artifacts (up to 6 active)
  if (game.player.artifacts.length < 6) {
    const owned = new Set(game.player.artifacts.map(a => a.id));
    for (const id of Object.keys(ARTIFACTS)) {
      if (owned.has(id)) continue;
      const def = ARTIFACTS[id];
      pool.push({
        type: 'artifact', artifactId: id, rarity: def.tier,
        title: def.name, tag: 'Artifact', desc: def.desc
      });
    }
  }

  // Pick 3 unique random
  const offered = [];
  const tries = pool.slice();
  while (offered.length < 3 && tries.length > 0) {
    const i = Math.floor(rand() * tries.length);
    offered.push(tries[i]);
    tries.splice(i, 1);
  }
  if (offered.length === 0) {
    // Heal as fallback
    game.player.hp = Math.min(game.player.maxHp, game.player.hp + 30);
    return;
  }

  game.cardOpen = true;
  game.pendingCards = offered;
  showCardOverlay(offered);
}

function pickCard(idx) {
  const card = game.pendingCards && game.pendingCards[idx];
  if (!card) return;
  if (card.type === 'weapon_lvl') {
    const w = game.player.weapons.find(x => x.id === card.weaponId);
    if (w) w.lvl = Math.min(8, w.lvl + 1);
  } else if (card.type === 'weapon_new') {
    game.player.weapons.push({ id: card.weaponId, lvl: 1, cd: 0, phase: 0 });
  } else if (card.type === 'artifact') {
    applyArtifact(card.artifactId);
    game.player.artifacts.push({ id: card.artifactId });
  }
  hideOverlay('card-overlay');
  game.cardOpen = false;
  game.pendingCards = null;
}

function applyArtifact(id) {
  const a = ARTIFACTS[id];
  const m = game.player.mods;
  switch (a.stat) {
    case 'projSpeedMul': m.projSpeedMul *= a.value; break;
    case 'projCountAdd': m.projCountAdd += a.value; break;
    case 'areaMul':      m.areaMul *= a.value; break;
    case 'moveSpeedMul': m.moveSpeedMul *= a.value; break;
    case 'pickupRadMul':
      m.pickupRadMul *= a.value;
      game.player.pickupRad *= a.value;
      break;
    case 'xpMul':        m.xpMul *= a.value; break;
    case 'maxHpAdd':
      game.player.maxHp += a.value;
      game.player.hp = game.player.maxHp;
      break;
    case 'cdMul':        m.cdMul *= a.value; break;
    case 'pierceAdd':    m.pierceAdd += a.value; break;
    case 'critBundle':   m.critChance += 0.15; m.critMult += 0.25; break;
  }
}

/* =============================================================
   FLOATS / UI HELPERS
   ============================================================= */
function pushFloat(x, y, text, color, life) {
  game.floats.push({ x, y, text, color: color || PAL.cream, life: life || 0.7 });
}

function fmtTime(t) {
  const m = Math.floor(t / 60), s = Math.floor(t % 60);
  return String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0');
}

/* =============================================================
   RENDERING
   ============================================================= */
function render() {
  // Clear
  ctx.fillStyle = PAL.bg0;
  ctx.fillRect(0, 0, W, H);

  // Tile floor (parallax against camera)
  const tileImg = SPRITES.tile;
  const ox = -Math.floor(game.cam.x % TILE) - TILE;
  const oy = -Math.floor(game.cam.y % TILE) - TILE;
  for (let y = oy; y < H + TILE; y += TILE) {
    for (let x = ox; x < W + TILE; x += TILE) {
      ctx.drawImage(tileImg, x, y);
    }
  }

  ctx.save();
  ctx.translate(W / 2 - game.cam.x, H / 2 - game.cam.y);

  // Pickup radius hint
  ctx.strokeStyle = 'rgba(255,184,74,0.15)';
  ctx.beginPath();
  ctx.arc(game.player.x, game.player.y, game.player.pickupRad, 0, Math.PI * 2);
  ctx.stroke();

  // Pickups
  for (const p of game.pickups) {
    let img;
    if (p.kind === 'ember') img = SPRITES.pickup_ember;
    else if (p.kind === 'gold') img = SPRITES.pickup_gold;
    else if (p.kind === 'heart') img = SPRITES.pickup_heart;
    else if (p.kind === 'chest') img = SPRITES.pickup_chest;
    if (img) ctx.drawImage(img, Math.round(p.x - img.width / 2), Math.round(p.y - img.height / 2));
  }

  // Enemies
  for (const e of game.enemies) {
    const img = e.boss ? SPRITES['boss_' + e.bossId] : SPRITES['enemy_' + e.type];
    if (img) {
      const w = img.width, h = img.height;
      if (e.elite) {
        // tint via composite
        ctx.save();
        ctx.drawImage(img, Math.round(e.x - w / 2), Math.round(e.y - h / 2));
        ctx.globalCompositeOperation = 'source-atop';
        ctx.fillStyle = 'rgba(255,107,61,0.35)';
        ctx.fillRect(Math.round(e.x - w / 2), Math.round(e.y - h / 2), w, h);
        ctx.restore();
      } else {
        ctx.drawImage(img, Math.round(e.x - w / 2), Math.round(e.y - h / 2));
      }
    } else {
      ctx.fillStyle = e.color;
      ctx.fillRect(Math.round(e.x - e.size / 2), Math.round(e.y - e.size / 2), e.size, e.size);
    }
    // Boss HP bar
    if (e.boss) {
      ctx.fillStyle = PAL.bg0;
      ctx.fillRect(Math.round(e.x - 24), Math.round(e.y - e.size - 8), 48, 5);
      ctx.fillStyle = PAL.red;
      ctx.fillRect(Math.round(e.x - 24), Math.round(e.y - e.size - 8), Math.round(48 * (e.hp / e.maxHp)), 5);
    }
  }

  // Bullets
  for (const b of game.bullets) {
    if (b.kind === 'ring') {
      ctx.strokeStyle = 'rgba(201,138,171,0.7)';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.arc(b.x, b.y, b.r, 0, Math.PI * 2);
      ctx.stroke();
      continue;
    }
    if (b.kind === 'orbit') {
      ctx.fillStyle = PAL.green;
      ctx.fillRect(Math.round(b.x - 3), Math.round(b.y - 3), 6, 6);
      ctx.fillStyle = PAL.darkGreen;
      ctx.fillRect(Math.round(b.x - 1), Math.round(b.y - 1), 2, 2);
      continue;
    }
    if (b.kind === 'beam') {
      ctx.save();
      ctx.translate(b.x, b.y);
      ctx.rotate(b.ang);
      ctx.fillStyle = PAL.amber;
      ctx.fillRect(-6, -2, 12, 4);
      ctx.fillStyle = PAL.cream;
      ctx.fillRect(-3, -1, 6, 2);
      ctx.restore();
      continue;
    }
    if (b.kind === 'anvil') {
      ctx.fillStyle = PAL.bg2;
      ctx.fillRect(Math.round(b.x - 5), Math.round(b.y - 4), 10, 8);
      ctx.fillStyle = PAL.mauve;
      ctx.fillRect(Math.round(b.x - 3), Math.round(b.y - 4), 6, 1);
      continue;
    }
    if (b.kind === 'dagger') {
      ctx.save();
      ctx.translate(b.x, b.y); ctx.rotate(b.ang);
      ctx.fillStyle = b.color;
      ctx.fillRect(-4, -1, 8, 2);
      ctx.fillStyle = PAL.bg2;
      ctx.fillRect(-5, -1, 1, 2);
      ctx.restore();
      continue;
    }
    if (b.kind === 'homing') {
      ctx.save();
      ctx.translate(b.x, b.y); ctx.rotate(b.ang);
      ctx.fillStyle = PAL.teal;
      ctx.fillRect(-5, -2, 10, 4);
      ctx.fillStyle = PAL.cream;
      ctx.fillRect(2, -1, 3, 2);
      ctx.restore();
      continue;
    }
    if (b.kind === 'enemy_bolt') {
      ctx.fillStyle = PAL.green;
      ctx.fillRect(Math.round(b.x - 3), Math.round(b.y - 3), 6, 6);
      ctx.fillStyle = PAL.darkGreen;
      ctx.fillRect(Math.round(b.x - 1), Math.round(b.y - 1), 2, 2);
      continue;
    }
  }

  // Player
  {
    const img = SPRITES['char_' + game.charDef.id];
    if (game.player.hurtFlash > 0) {
      ctx.save();
      ctx.globalCompositeOperation = 'source-over';
      ctx.drawImage(img, Math.round(game.player.x - img.width / 2), Math.round(game.player.y - img.height / 2));
      ctx.globalCompositeOperation = 'source-atop';
      ctx.fillStyle = 'rgba(214,61,46,0.6)';
      ctx.fillRect(Math.round(game.player.x - img.width / 2), Math.round(game.player.y - img.height / 2), img.width, img.height);
      ctx.restore();
    } else {
      ctx.drawImage(img, Math.round(game.player.x - img.width / 2), Math.round(game.player.y - img.height / 2));
    }
  }

  // Particles
  for (const p of game.particles) {
    ctx.fillStyle = p.color;
    ctx.fillRect(Math.round(p.x), Math.round(p.y), 2, 2);
  }

  // Float text
  ctx.font = '10px ui-monospace, Consolas, monospace';
  ctx.textAlign = 'center';
  for (const f of game.floats) {
    ctx.fillStyle = f.color;
    ctx.globalAlpha = Math.min(1, f.life * 1.6);
    ctx.fillText(f.text, Math.round(f.x), Math.round(f.y));
    ctx.globalAlpha = 1;
  }

  ctx.restore();

  // Subtle vignette
  const grd = ctx.createRadialGradient(W / 2, H / 2, 200, W / 2, H / 2, 480);
  grd.addColorStop(0, 'rgba(0,0,0,0)');
  grd.addColorStop(1, 'rgba(0,0,0,0.55)');
  ctx.fillStyle = grd;
  ctx.fillRect(0, 0, W, H);

  drawMinimap();
}

function drawMinimap() {
  const w = mini.width, h = mini.height;
  mctx.fillStyle = PAL.bg0;
  mctx.fillRect(0, 0, w, h);
  const scale = 0.06;
  // enemies
  for (const e of game.enemies) {
    const x = w / 2 + (e.x - game.player.x) * scale;
    const y = h / 2 + (e.y - game.player.y) * scale;
    if (x < 0 || x >= w || y < 0 || y >= h) continue;
    mctx.fillStyle = e.boss ? PAL.amber : (e.elite ? PAL.orange : PAL.red);
    mctx.fillRect(x, y, e.boss ? 3 : 2, e.boss ? 3 : 2);
  }
  // pickups (chests only)
  for (const p of game.pickups) {
    if (p.kind !== 'chest') continue;
    const x = w / 2 + (p.x - game.player.x) * scale;
    const y = h / 2 + (p.y - game.player.y) * scale;
    if (x < 0 || x >= w || y < 0 || y >= h) continue;
    mctx.fillStyle = PAL.cream;
    mctx.fillRect(x - 1, y - 1, 3, 3);
  }
  // player
  mctx.fillStyle = PAL.amber;
  mctx.fillRect(w / 2 - 1, h / 2 - 1, 3, 3);
}

/* =============================================================
   DOM HUD
   ============================================================= */
function updateHUD() {
  if (!game.player) return;
  const hpFill = document.getElementById('hp-fill');
  hpFill.style.width = Math.max(0, (game.player.hp / game.player.maxHp) * 100) + '%';
  document.getElementById('hp-text').textContent = `${Math.ceil(game.player.hp)} / ${Math.ceil(game.player.maxHp)}`;
  document.getElementById('xp-fill').style.width = ((game.player.xp / game.player.xpToNext) * 100) + '%';
  document.getElementById('lvl-text').textContent = game.player.level;
  document.getElementById('run-time').textContent = fmtTime(game.t);
  document.getElementById('ember-count').textContent = game.emberCount;
  document.getElementById('kill-count').textContent = game.killCount;

  // Weapon icons
  const wRow = document.getElementById('weapons-row');
  const aRow = document.getElementById('artifacts-row');
  if (wRow.dataset.sig !== weaponSig()) {
    wRow.innerHTML = '';
    for (const w of game.player.weapons) {
      const def = WEAPONS[w.id];
      const el = document.createElement('div');
      el.className = 'icon';
      el.innerHTML = `${def.icon}<span class="lvl-pip">${w.lvl}</span>`;
      el.title = def.name + ' Lv ' + w.lvl;
      wRow.appendChild(el);
    }
    wRow.dataset.sig = weaponSig();
  }
  if (aRow.dataset.sig !== artifactSig()) {
    aRow.innerHTML = '';
    for (const a of game.player.artifacts) {
      const def = ARTIFACTS[a.id];
      const el = document.createElement('div');
      el.className = 'icon';
      el.textContent = def.name[0];
      el.title = def.name + ' — ' + def.desc;
      aRow.appendChild(el);
    }
    aRow.dataset.sig = artifactSig();
  }
}
function weaponSig()  { return game.player.weapons.map(w => w.id + w.lvl).join(','); }
function artifactSig(){ return game.player.artifacts.map(a => a.id).join(','); }

function showCardOverlay(cards) {
  const root = document.getElementById('cards');
  root.innerHTML = '';
  cards.forEach((c, i) => {
    const el = document.createElement('div');
    el.className = 'card rarity-' + (c.rarity || 'C');
    el.innerHTML = `
      <div class="card-tag">${c.tag}</div>
      <div class="card-name">${c.title}</div>
      <div class="card-desc">${c.desc}</div>
      <span class="card-key">[${i + 1}]</span>`;
    el.onclick = () => pickCard(i);
    root.appendChild(el);
  });
  showOverlay('card-overlay');
}

function showOverlay(id) { document.getElementById(id).classList.remove('hidden'); }
function hideOverlay(id) { document.getElementById(id).classList.add('hidden'); }

function togglePause() {
  if (!game.running || game.cardOpen || game.ended) return;
  game.paused = !game.paused;
  if (game.paused) showOverlay('pause-overlay');
  else hideOverlay('pause-overlay');
}

/* =============================================================
   TITLE / META SHOP / CHARACTER SELECT
   ============================================================= */
function buildTitleScreen() {
  document.getElementById('shard-balance').textContent = '★ ' + meta.shards;

  // Character cards
  const cs = document.getElementById('char-select');
  cs.innerHTML = '';
  CHARACTERS.forEach((ch, i) => {
    const def = WEAPONS[ch.starter];
    const el = document.createElement('div');
    el.className = 'card rarity-C';
    el.innerHTML = `
      <div class="card-tag">Character</div>
      <div class="card-name">${ch.name}</div>
      <div class="card-desc">
        <em>${ch.flavor}</em><br>
        Starter: <b>${def.name}</b><br>
        Passive: ${describePassive(ch.passive)}
      </div>
      <span class="card-key">START</span>`;
    el.onclick = () => startRun(ch.id);
    cs.appendChild(el);
  });

  // Shop
  const shop = document.getElementById('shop');
  shop.innerHTML = '';
  for (const def of SHOP_DEFS) {
    const tier = meta.upgrades[def.id];
    const cost = def.costFn(tier);
    const maxed = tier >= def.max;
    const el = document.createElement('div');
    el.className = 'shop-item' + (maxed ? ' maxed' : '');
    el.innerHTML = `
      <span class="shop-name">${def.name} <span class="shop-cost">${maxed ? 'MAX' : '★ ' + cost}</span></span>
      <span class="shop-stat">${def.stat}</span><br>
      <small>Tier ${tier} / ${def.max}</small>`;
    el.onclick = () => {
      if (maxed) return;
      if (meta.shards < cost) { flash(el); return; }
      meta.shards -= cost;
      meta.upgrades[def.id]++;
      saveMeta();
      buildTitleScreen();
    };
    shop.appendChild(el);
  }
}

function describePassive(p) {
  if (p.type === 'pickup_radius') return `+${(p.value * 100) | 0}% pickup radius`;
  if (p.type === 'weapon_area')   return `+${(p.value * 100) | 0}% weapon area`;
  if (p.type === 'damage')        return `+${(p.value * 100) | 0}% damage, −${(p.speedPenalty * 100) | 0}% move speed`;
  return '—';
}

function flash(el) {
  el.style.transition = 'background 80ms';
  const old = el.style.background;
  el.style.background = PAL.red;
  setTimeout(() => { el.style.background = old; }, 120);
}

/* =============================================================
   MAIN LOOP
   ============================================================= */
let last = performance.now();
function loop(now) {
  const dt = Math.min(0.05, (now - last) / 1000);
  last = now;
  if (game.running) {
    update(dt);
    render();
    updateHUD();
  }
  requestAnimationFrame(loop);
}

/* =============================================================
   BOOT
   ============================================================= */
buildSprites();
buildTitleScreen();

document.getElementById('hud').style.visibility = 'hidden';
document.getElementById('resume-btn').onclick = togglePause;
document.getElementById('quit-btn').onclick = () => {
  hideOverlay('pause-overlay');
  endRun(false);
};
document.getElementById('end-btn').onclick = () => {
  hideOverlay('end-overlay');
  document.getElementById('hud').style.visibility = 'hidden';
  buildTitleScreen();
  showOverlay('title-overlay');
};

requestAnimationFrame(loop);

// Expose for tinkering in DevTools
window.Emberfall = { game, WEAPONS, ENEMIES, ARTIFACTS, CHARACTERS, meta, seedRng };

})();
